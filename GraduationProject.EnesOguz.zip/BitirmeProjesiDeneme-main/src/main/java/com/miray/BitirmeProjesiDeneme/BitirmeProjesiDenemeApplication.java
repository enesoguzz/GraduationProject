package com.miray.BitirmeProjesiDeneme;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BitirmeProjesiDenemeApplication {
	public static void main(String[] args) {
		SpringApplication.run(BitirmeProjesiDenemeApplication.class, args);
	}

}
